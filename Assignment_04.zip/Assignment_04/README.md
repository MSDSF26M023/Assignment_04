# Assignment 4 – Loan EMI Calculator on Kubernetes (Minikube)

Node.js/Express app + MongoDB 3-member replica set (StatefulSet) + NGINX Ingress + HPA.

```
app/      source code, Dockerfile, .dockerignore
k8s/      all manifests (apply with: kubectl apply -f k8s/)
          k8s/autoscaling/hpa.yaml  -> applied only for the autoscaling test (see step 8)
scripts/  loadgen.py, monitor.py, run_experiments.py, run_autoscale.py,
          distribution.py, request_loop.py, make_graphs.py
results/  raw CSVs, graphs
```

Requirements: Docker, Minikube, kubectl, Python 3.9+ (`pip install psutil pandas matplotlib`), Node 20 (only for local testing).

## 0. Local test (Milestone 1)
```bash
docker run -d --name mongo-local -p 27017:27017 mongo:7.0
cd app && npm install
MONGO_URL=mongodb://localhost:27017/emidb npm start      # http://localhost:3000
```
(PowerShell: `$env:MONGO_URL="mongodb://localhost:27017/emidb"; npm start`)

## 1. Start Minikube
```bash
minikube start --driver=docker --cpus=4 --memory=6144
minikube addons enable metrics-server
minikube addons enable ingress
kubectl get pods -n ingress-nginx        # wait until controller is Running
```

## 2. Build and load the image
```bash
docker build -t emi-web:1.0 app/
minikube image load emi-web:1.0
```

## 3. Deploy everything
```bash
kubectl apply -f k8s/
kubectl get pods -n emi -w               # mongo-0..2 Running, mongo-init Completed, emi-web 3/3 Ready
kubectl logs job/mongo-init -n emi
kubectl get all,pvc,configmap -n emi -o wide
kubectl exec -n emi mongo-0 -- mongosh --quiet --eval 'rs.status().members.forEach(m => print(m.name, m.stateStr))'
```
`k8s/autoscaling/hpa.yaml` is NOT applied by this command (kubectl is not recursive), because an HPA would
override `kubectl scale` in the fixed-replica experiments.

## 4. Verify with port-forward
```bash
kubectl port-forward svc/emi-web 8080:80 -n emi      # open http://localhost:8080
```

## 5. Persistence test (mongo-1)
```bash
URL='mongodb://mongo-0.mongo:27017,mongo-1.mongo:27017,mongo-2.mongo:27017/emidb?replicaSet=rs0'
kubectl exec -n emi mongo-0 -- mongosh "$URL" --quiet --eval 'db.calculations.countDocuments()'   # BEFORE
kubectl get pod mongo-1 -n emi -o wide ; kubectl get pvc -n emi
kubectl delete pod mongo-1 -n emi
kubectl get pods -n emi -w                                  # mongo-1 comes back, AGE is small
kubectl get pod mongo-1 -n emi -o jsonpath='{.spec.volumes[*].persistentVolumeClaim.claimName}'   # data-mongo-1
kubectl get pvc -n emi                                      # same PVC, old AGE
kubectl exec -n emi mongo-0 -- mongosh "$URL" --quiet --eval 'db.calculations.countDocuments()'   # AFTER (same count)
```

## 6. Ingress (Milestone 3)
Add to hosts file (Linux: `/etc/hosts`, Windows: `C:\Windows\System32\drivers\etc\hosts`):
* Linux: `<output of minikube ip>  emi.local`
* Windows/macOS (Docker driver): `127.0.0.1  emi.local` and keep `minikube tunnel` running in another terminal.

Open http://emi.local

```bash
cd scripts
python distribution.py --n 30                                 # 3 replicas -> table
kubectl scale deployment emi-web --replicas=5 -n emi
kubectl get pods -n emi -w                                    # new pods not Ready yet -> no traffic yet
python distribution.py --n 30                                 # run again right away, then once all 5 are Ready
kubectl scale deployment emi-web --replicas=3 -n emi
```
Self-healing (keep `python request_loop.py --duration 120 --log ../results/selfheal_loop.csv` running in one terminal):
```bash
kubectl get pods -n emi -w                                     # second terminal
kubectl delete pod <one-emi-web-pod> -n emi
# find primary:
kubectl exec -n emi mongo-0 -- mongosh --quiet --eval 'rs.status().members.filter(m => m.stateStr=="PRIMARY")[0].name'
kubectl delete pod <that-mongo-pod> -n emi                     # new primary elected, app keeps saving
kubectl exec -n emi mongo-1 -- mongosh --quiet --eval 'rs.status().members.forEach(m => print(m.name, m.stateStr))'
```
Rolling update + rollback:
```bash
# edit app/public/index.html footer to "version 1.1" and app/package.json "version" to 1.1.0
docker build -t emi-web:1.1 app/
minikube image load emi-web:1.1
python scripts/request_loop.py --duration 150 --log results/rolling_update_loop.csv      # terminal A
kubectl annotate deployment/emi-web -n emi kubernetes.io/change-cause="update to 1.1" --overwrite
kubectl set image deployment/emi-web web=emi-web:1.1 -n emi                              # terminal B
kubectl rollout status deployment/emi-web -n emi
kubectl rollout history deployment/emi-web -n emi
kubectl rollout undo deployment/emi-web -n emi
kubectl rollout status deployment/emi-web -n emi
kubectl get deploy emi-web -n emi -o jsonpath='{.spec.template.spec.containers[0].image}'   # emi-web:1.0 again
```
The loop prints `TOTAL=.. FAILED=0` at the end.

## 7. Fixed-replica load tests (Milestone 4, 15 runs, ~40 min)
```bash
cd scripts
python run_experiments.py          # writes results/fixed_runs_summary.csv and results/raw/*
```
Close other heavy programs while it runs. Every request is `POST /api/emi` with random valid inputs.

## 8. Autoscaling test (10 min)
```bash
cd scripts
python run_autoscale.py            # applies k8s/autoscaling/hpa.yaml, runs 10x120,100x300,10x180
kubectl get hpa emi-web -n emi     # (also recorded every 15 s in results/autoscale/autoscale_hpa_raw.txt)
```

## 9. Graphs
```bash
cd scripts && python make_graphs.py     # results/graph1..3 .png
```

## Notes
* Pod CPU % in Graph 2 = `kubectl top` millicores / 100m CPU request (same basis the HPA uses).
* Cleanup: `kubectl delete ns emi` (PVCs are removed with the namespace) / `minikube delete`.
