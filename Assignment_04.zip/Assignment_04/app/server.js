'use strict';
const express = require('express');
const os = require('os');
const path = require('path');
const { MongoClient } = require('mongodb');
const pkg = require('./package.json');

const PORT = parseInt(process.env.PORT || '3000', 10);
const MONGO_URL = process.env.MONGO_URL;          // never hard-coded
if (!MONGO_URL) {
  console.error('FATAL: MONGO_URL environment variable is not set');
  process.exit(1);
}
const POD_NAME = process.env.HOSTNAME || os.hostname();
const VERSION = pkg.version;

function podIp() {
  if (process.env.POD_IP) return process.env.POD_IP;   // injected via downward API
  for (const list of Object.values(os.networkInterfaces())) {
    for (const i of list || []) {
      if ((i.family === 'IPv4' || i.family === 4) && !i.internal) return i.address;
    }
  }
  return 'unknown';
}
const POD_IP = podIp();

// serverSelectionTimeoutMS is long enough for a replica-set election (~10 s)
const client = new MongoClient(MONGO_URL, {
  serverSelectionTimeoutMS: 15000,
  connectTimeoutMS: 5000,
  maxPoolSize: 50,
});
let calculations = null;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function connectWithRetry() {
  for (;;) {
    try {
      await client.connect();
      const col = client.db().collection('calculations');   // db name comes from MONGO_URL (emidb)
      await col.createIndex({ createdAt: -1 });
      calculations = col;
      console.log('Connected to MongoDB');
      return;
    } catch (e) {
      console.error('MongoDB not ready yet:', e.message);
      await sleep(3000);
    }
  }
}

function withTimeout(promise, ms) {
  let t;
  const timeout = new Promise((_, rej) => { t = setTimeout(() => rej(new Error('timeout')), ms); });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(t));
}

const round2 = (x) => Math.round(x * 100) / 100;

function validate(P, rate, n) {
  if (![P, rate, n].every(Number.isFinite)) return 'P, rate and n must be numbers';
  if (P <= 0 || rate <= 0 || n <= 0) return 'P, rate and n must be positive numbers';
  if (!Number.isInteger(n)) return 'n (months) must be a whole number';
  if (P > 1e12) return 'P is too large';
  if (rate > 100) return 'rate must be 100 or less';
  if (n > 1200) return 'n must be 1200 months or less';
  return null;
}

const app = express();
app.disable('x-powered-by');
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/health', async (req, res) => {
  if (!calculations) return res.status(503).json({ status: 'down', reason: 'mongodb not connected yet' });
  try {
    // secondaryPreferred: stay Ready while any member answers (e.g. during a primary election)
    await withTimeout(
      client.db('admin').command({ ping: 1 }, { readPreference: 'secondaryPreferred' }),
      2000
    );
    res.status(200).json({ status: 'ok', servedBy: POD_NAME });
  } catch (e) {
    res.status(503).json({ status: 'down', reason: e.message });
  }
});

app.post('/api/emi', async (req, res) => {
  const body = req.body || {};
  const P = Number(body.P), rate = Number(body.rate), n = Number(body.n);
  const err = validate(P, rate, n);
  if (err) return res.status(400).json({ error: err });

  const r = rate / 12 / 100;
  const pm1 = Math.expm1(n * Math.log1p(r));        // (1+r)^n - 1, numerically stable
  const emi = (P * r * (pm1 + 1)) / pm1;            // P r (1+r)^n / ((1+r)^n - 1)
  if (!Number.isFinite(emi)) return res.status(400).json({ error: 'values out of range' });
  const totalPayment = emi * n;
  const totalInterest = totalPayment - P;
  const result = {
    emi: round2(emi),
    totalPayment: round2(totalPayment),
    totalInterest: round2(totalInterest),
    servedBy: POD_NAME,
    podIp: POD_IP,
    version: VERSION,
  };

  if (!calculations) return res.status(503).json({ error: 'database not available' });
  try {
    await calculations.insertOne({
      principal: P, rate, months: n, emi: result.emi,
      servedBy: POD_NAME, createdAt: new Date(),
    });
  } catch (e) {
    console.error('insert failed:', e.message);
    return res.status(503).json({ error: 'could not save calculation' });
  }
  res.json(result);
});

app.get('/api/history', async (req, res) => {
  if (!calculations) return res.status(503).json({ error: 'database not available' });
  try {
    const rows = await calculations.find({}, { projection: { _id: 0 } })
      .sort({ createdAt: -1 }).limit(10).toArray();
    res.json(rows);
  } catch (e) {
    res.status(503).json({ error: 'could not read history' });
  }
});

// JSON errors (e.g. malformed JSON body)
app.use((err, req, res, next) => {          // eslint-disable-line no-unused-vars
  res.status(err.status || 500).json({ error: err.status === 400 ? 'bad request' : 'server error' });
});

const server = app.listen(PORT, () => console.log(`emi-web ${VERSION} on :${PORT} (pod ${POD_NAME})`));
server.keepAliveTimeout = 65000;   // longer than NGINX ingress keep-alive -> no random 502s
server.headersTimeout = 66000;
connectWithRetry();

function shutdown(sig) {
  console.log(`${sig} received, shutting down`);
  server.close(async () => {
    try { await client.close(); } catch (e) { /* ignore */ }
    process.exit(0);
  });
  setTimeout(() => process.exit(0), 10000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
