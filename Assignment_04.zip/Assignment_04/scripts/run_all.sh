#!/bin/bash

ulimit -n 65535

echo "replicas,rate,avg_ms,errors" > results/summary.csv

for R in 1 2 3; do

    echo "Testing with $R replicas"

    kubectl scale deployment emi-web --replicas=$R -n emi
    kubectl rollout status deployment/emi-web -n emi

    sleep 30

    for RATE in 10 25 50 100 200; do

        TAG="r${R}_rate${RATE}"

        echo "Running $TAG"

        python3 scripts/profiler.py $TAG 60 &
        PROF=$!

        ./scripts/run_httperf.sh $RATE 60 $TAG

        wait $PROF

        read AVG ERR < <(python3 scripts/parse_httperf.py results/${TAG}_httperf.txt)

        echo "$R,$RATE,$AVG,$ERR" >> results/summary.csv

        sleep 30

    done
done

echo "All experiments completed!"

