import re
import sys

t = open(sys.argv[1]).read()

avg = float(re.search(
    r"Reply time \[ms\]: response ([\d.]+)", t
).group(1))

err = int(re.search(
    r"Errors: total (\d+)", t
).group(1))

m = re.search(
    r"Reply status: 1xx=\d+ 2xx=(\d+) 3xx=\d+ 4xx=\d+ 5xx=(\d+)", t
)

bad = int(m.group(2))

print(avg, err + bad)
