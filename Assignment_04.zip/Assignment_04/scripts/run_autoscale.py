#!/usr/bin/env python3
"""Milestone 4 / step 4: HPA test with httperf. 2 min @10 req/s, 5 min @100 req/s, 3 min @10 req/s.
`kubectl get hpa` (replicas, CPU%) is recorded every 15 s together with kubectl top and host CPU.
Output in ../results/autoscale/
"""
import csv, os, subprocess, time
import sys
import httperf_run, preflight
from monitor import Monitor

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "results", "autoscale")
HPA = os.path.join(HERE, "..", "k8s", "autoscaling", "hpa.yaml")
PHASES = [(10, 120), (100, 300), (10, 180)]


def k(*a, **kw):
    return subprocess.run(["kubectl", *a], check=False, **kw)


if not preflight.check():
    sys.exit('Fix the FAIL items above first, then run again.')
os.makedirs(OUT, exist_ok=True)
k("scale", "deployment", "emi-web", "--replicas=1", "-n", "emi")
k("rollout", "status", "deployment/emi-web", "-n", "emi", "--timeout=120s")
k("apply", "-f", HPA)
print("waiting 45 s for HPA metrics ...")
time.sleep(45)
mon = Monitor(os.path.join(OUT, "autoscale"), hpa=True)
mon.start()
with open(os.path.join(OUT, "phases.csv"), "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["start_ts", "end_ts", "rate_req_s", "sent", "ok", "errors", "avg_ms"])
    for i, (rate, dur) in enumerate(PHASES, 1):
        t0 = time.time()
        s = httperf_run.run(rate, dur, raw_out=os.path.join(OUT, "httperf_phase%d.txt" % i))
        w.writerow([round(t0, 2), round(time.time(), 2), rate, s["sent"], s["ok"], s["errors"], s["avg_ms"]])
        f.flush()
        print("phase", i, rate, "req/s ->", s, flush=True)
mon.stop()
if mon.top_rows == 0:
    print('WARNING: no kubectl top data was recorded - redo this test after fixing metrics-server')
with open(os.path.join(OUT, "hpa_describe.txt"), "w") as f:
    k("describe", "hpa", "emi-web", "-n", "emi", stdout=f)
print("saved to", OUT)
