#!/bin/bash

RATE=$1
DUR=$2
TAG=$3

N=$((RATE*DUR))

python3 scripts/gen_sessions.py $N /tmp/sess_$TAG.txt

httperf --server emi.local --port 80 \
--wsesslog=$N,0,/tmp/sess_$TAG.txt \
--rate=$RATE --timeout=10 \
--add-header='Content-Type: application/json\n' \
> results/${TAG}_httperf.txt 2>&1

