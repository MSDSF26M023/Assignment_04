import random
import sys

n, out = int(sys.argv[1]), sys.argv[2]

with open(out, "w") as f:
    for _ in range(n):
        p = random.randint(50000, 5000000)
        r = round(random.uniform(5, 20), 2)
        months = random.randint(6, 120)

        f.write(
            f"/api/emi method=POST contents='{{\"P\":{p},\"rate\":{r},\"n\":{months}}}'\n\n"
        )
