#!/usr/bin/env python3
"""Runs httperf for one constant-rate phase. Every request is POST /api/emi with RANDOM valid inputs
(a fresh httperf --wsesslog session file is generated for each run: one session = one request).
Usage:  python httperf_run.py --rate 100 --duration 60
"""
import argparse, os, random, re, subprocess, tempfile

SERVER = os.environ.get("EMI_HOST", "emi.local")
PORT = int(os.environ.get("EMI_PORT", "80"))
PATH = "/api/emi"


def write_sessions(path, n):
    with open(path, "w") as f:
        for _ in range(n):
            f.write("%s method=POST contents='P=%d&rate=%d&n=%d'\n\n" % (
                PATH, random.randint(10_000, 5_000_000), random.randint(1, 30), random.randint(6, 360)))


def run(rate, duration, raw_out=None, timeout=3, server=SERVER, port=PORT):
    n = int(round(rate * duration))
    fd, sess = tempfile.mkstemp(suffix=".sessions")
    os.close(fd)
    try:
        write_sessions(sess, n)
        cmd = ["httperf", "--server", server, "--port", str(port),
               "--rate", str(rate), "--num-conns", str(n), "--timeout", str(timeout),
               "--wsesslog=%d,0,%s" % (n, sess),
               "--add-header=Content-Type: application/x-www-form-urlencoded\\n"]
        out = subprocess.run(cmd, capture_output=True, text=True).stdout
    finally:
        os.remove(sess)
    if raw_out:
        os.makedirs(os.path.dirname(os.path.abspath(raw_out)), exist_ok=True)
        with open(raw_out, "w") as f:
            f.write(" ".join(cmd) + "\n\n" + out)
    return parse(out)


def parse(out):
    def g(pat, default=0.0):
        m = re.search(pat, out)
        return float(m.group(1)) if m else default
    requests = int(g(r"Total: connections \d+ requests (\d+)"))
    replies = int(g(r"replies (\d+)"))
    ok = int(g(r"2xx=(\d+)"))
    err_total = int(g(r"Errors: total (\d+)"))
    avg = g(r"Reply time \[ms\]: response ([\d.]+)") + g(r"Reply time \[ms\]: response [\d.]+ transfer ([\d.]+)")
    return {"sent": requests, "replies": replies, "ok": ok,
            "errors": err_total + (replies - ok),      # timeouts/resets + non-2xx replies
            "avg_ms": round(avg, 2),
            "req_rate": g(r"Request rate: ([\d.]+) req/s")}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--rate", type=float, required=True)
    ap.add_argument("--duration", type=int, default=60)
    a = ap.parse_args()
    print(run(a.rate, a.duration))
