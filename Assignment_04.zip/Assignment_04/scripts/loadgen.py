#!/usr/bin/env python3
"""Open-loop load generator: POST /api/emi with RANDOM valid inputs at a fixed request rate.

Examples
  python loadgen.py --rate 100 --duration 60
  python loadgen.py --phases 10x120,100x300,10x180 --timeline ../results/autoscale/timeline.csv
(phase format = RATExSECONDS, comma separated)
Latency is measured per request from send to full response (like ab/httperf).
"""
import argparse, csv, http.client, json, os, random, statistics, threading, time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse

_tls = threading.local()


def _body():
    return json.dumps({
        "P": random.randint(10_000, 5_000_000),
        "rate": round(random.uniform(1, 30), 2),
        "n": random.randint(6, 360),
    })


def _post(host, port, path, timeout):
    t0 = time.perf_counter()
    ok = False
    try:
        conn = getattr(_tls, "conn", None)
        if conn is None:
            conn = http.client.HTTPConnection(host, port, timeout=timeout)
            _tls.conn = conn
        conn.request("POST", path, _body(), {"Content-Type": "application/json"})
        resp = conn.getresponse()
        resp.read()
        ok = resp.status == 200
    except Exception:
        c = getattr(_tls, "conn", None)
        if c is not None:
            try:
                c.close()
            except Exception:
                pass
        _tls.conn = None
    return ok, (time.perf_counter() - t0) * 1000.0


def parse_phases(text):
    out = []
    for p in text.split(","):
        r, d = p.lower().split("x")
        out.append((float(r), int(d)))
    return out


def run_phases(url, phases, workers=300, timeout=10, timeline_csv=None):
    u = urlparse(url)
    host, port, path = u.hostname, u.port or 80, u.path or "/api/emi"
    lock = threading.Lock()
    buckets = {}          # second -> [sent, ok, errors, latency_sum_ok]
    lats = []
    pool = ThreadPoolExecutor(max_workers=workers)
    start_wall = time.time()
    start = time.perf_counter()

    def done(fut, sec):
        ok, ms = fut.result()
        with lock:
            b = buckets[sec]
            if ok:
                b[1] += 1
                b[3] += ms
                lats.append(ms)
            else:
                b[2] += 1

    phase_start = start
    for rate, dur in phases:
        for i in range(int(round(rate * dur))):
            delay = (phase_start + i / rate) - time.perf_counter()
            if delay > 0:
                time.sleep(delay)          # if we are late we do not sleep -> catch up
            sec = int(time.perf_counter() - start)
            with lock:
                buckets.setdefault(sec, [0, 0, 0, 0.0])[0] += 1
            pool.submit(_post, host, port, path, timeout).add_done_callback(
                lambda f, s=sec: done(f, s))
        phase_start += dur
    pool.shutdown(wait=True)

    sent = sum(b[0] for b in buckets.values())
    ok = sum(b[1] for b in buckets.values())
    err = sum(b[2] for b in buckets.values())
    summary = {
        "sent": sent, "ok": ok, "errors": err,
        "avg_ms": round(statistics.mean(lats), 2) if lats else None,
        "p95_ms": round(statistics.quantiles(lats, n=20)[18], 2) if len(lats) >= 20 else None,
    }
    if timeline_csv:
        os.makedirs(os.path.dirname(os.path.abspath(timeline_csv)), exist_ok=True)
        with open(timeline_csv, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["timestamp", "elapsed_s", "sent_per_s", "ok", "errors", "avg_ms"])
            for sec in sorted(buckets):
                s, o, e, ls = buckets[sec]
                w.writerow([int(start_wall) + sec, sec, s, o, e, round(ls / o, 2) if o else ""])
    return summary


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://emi.local/api/emi")
    ap.add_argument("--rate", type=float, help="requests per second (single phase)")
    ap.add_argument("--duration", type=int, default=60)
    ap.add_argument("--phases", help="e.g. 10x120,100x300,10x180")
    ap.add_argument("--workers", type=int, default=300)
    ap.add_argument("--timeout", type=float, default=10)
    ap.add_argument("--timeline", help="write per-second CSV here")
    a = ap.parse_args()
    ph = parse_phases(a.phases) if a.phases else [(a.rate, a.duration)]
    if ph[0][0] is None:
        ap.error("give --rate or --phases")
    print(json.dumps(run_phases(a.url, ph, a.workers, a.timeout, a.timeline)))
