#!/usr/bin/env python3
import argparse, csv, os, subprocess, sys, time
import preflight
from loadgen import run_phases
from monitor import Monitor

DURATION = 60
URL = "http://emi.local/api/emi"
RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results")
PATH = os.path.join(RES, "fixed_runs_summary.csv")
FIELDS = ["replicas", "rate", "duration_s", "sent", "ok", "errors", "avg_ms"]

def k(*a):
    return subprocess.run(["kubectl", *a], check=False)

def load():
    rows = {}
    if os.path.exists(PATH):
        with open(PATH) as f:
            for r in csv.DictReader(f):
                rows[(int(r["replicas"]), int(r["rate"]))] = r
    return rows

def save(rows):
    with open(PATH, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        for key in sorted(rows):
            w.writerow(rows[key])

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--replicas", type=int, nargs="+", default=[1, 2, 3])
    ap.add_argument("--rates", type=int, nargs="+", default=[10, 25, 50, 100, 200])
    ap.add_argument("--skip-preflight", action="store_true")
    a = ap.parse_args()

    if not a.skip_preflight and not preflight.check():
        sys.exit("Fix the FAIL items above first.")

    os.makedirs(os.path.join(RES, "raw"), exist_ok=True)
    k("delete", "hpa", "emi-web", "-n", "emi", "--ignore-not-found")
    rows = load()

    for rep in a.replicas:
        k("scale", "deployment", "emi-web", "--replicas=%d" % rep, "-n", "emi")
        k("rollout", "status", "deployment/emi-web", "-n", "emi", "--timeout=180s")
        time.sleep(20)

        print("Warm-up: 5 req/s for 10 seconds", flush=True)
        run_phases(URL, [(5, 10)])

        for rate in a.rates:
            prefix = os.path.join(RES, "raw", "r%d_rate%d" % (rep, rate))
            print("== replicas=%d rate=%d req/s ==" % (rep, rate), flush=True)

            mon = Monitor(prefix)
            mon.start()
            s = run_phases(URL, [(rate, DURATION)])
            mon.stop()

            print("   ", s, "| kubectl-top rows:", mon.top_rows, flush=True)

            rows[(rep, rate)] = dict(zip(FIELDS, [
                rep, rate, DURATION, s["sent"], s["ok"],
                s["errors"], s["avg_ms"]
            ]))
            save(rows)
            time.sleep(30)

    print("Saved:", PATH)

if __name__ == "__main__":
    main()
