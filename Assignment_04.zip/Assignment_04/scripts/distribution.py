#!/usr/bin/env python3
"""Milestone 3: send N requests through the Ingress and count requests per pod (servedBy).
   python distribution.py --n 30
"""
import argparse, collections, http.client, json, random
from urllib.parse import urlparse

ap = argparse.ArgumentParser()
ap.add_argument("--url", default="http://emi.local/api/emi")
ap.add_argument("--n", type=int, default=30)
a = ap.parse_args()
u = urlparse(a.url)
counts, failed = collections.Counter(), 0
for _ in range(a.n):
    body = json.dumps({"P": random.randint(10000, 900000), "rate": random.randint(5, 25), "n": random.randint(6, 60)})
    try:
        c = http.client.HTTPConnection(u.hostname, u.port or 80, timeout=10)   # new connection per request
        c.request("POST", u.path or "/", body, {"Content-Type": "application/json", "Connection": "close"})
        r = c.getresponse()
        data = json.loads(r.read())
        c.close()
        if r.status == 200:
            counts[data["servedBy"]] += 1
        else:
            failed += 1
    except Exception:
        failed += 1
print("%-32s %s" % ("POD", "REQUESTS"))
for pod, n in sorted(counts.items()):
    print("%-32s %d" % (pod, n))
print("%-32s %d" % ("TOTAL OK", sum(counts.values())))
print("%-32s %d" % ("FAILED", failed))
