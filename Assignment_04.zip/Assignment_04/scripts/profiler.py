import subprocess
import time
import csv
import threading
import psutil
import sys

tag, duration = sys.argv[1], int(sys.argv[2])
stop = time.time() + duration

def host_cpu():
    with open(f"results/{tag}_host.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["timestamp", "host_cpu_percent"])

        while time.time() < stop:
            w.writerow([time.time(), psutil.cpu_percent(interval=1)])
            f.flush()

def pods_top():
    with open(f"results/{tag}_pods.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["timestamp", "pod", "cpu_m", "mem_Mi"])

        while time.time() < stop:
            out = subprocess.run(
                ["kubectl", "top", "pods", "-n", "emi", "--no-headers"],
                capture_output=True,
                text=True
            ).stdout

            ts = time.time()

            for line in out.strip().splitlines():
                p = line.split()

                if p[0].startswith("emi-web"):
                    w.writerow([
                        ts,
                        p[0],
                        p[1].rstrip("m"),
                        p[2].rstrip("Mi")
                    ])

            f.flush()
            time.sleep(15)

a = threading.Thread(target=host_cpu)
b = threading.Thread(target=pods_top)

a.start()
b.start()

a.join()
b.join()
