#!/usr/bin/env python3
"""Creates the 3 required graphs from ../results.  pip3 install pandas matplotlib"""
import os
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

R = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "results"))
CPU_REQUEST_M = 100          # CPU request of each web pod (100m): utilisation % is relative to it, like the HPA
RATES = [10, 25, 50, 100, 200]


def graph1():
    df = pd.read_csv(os.path.join(R, "fixed_runs_summary.csv"))
    fig, ax = plt.subplots(figsize=(8, 5))
    for rep, g in sorted(df.groupby("replicas")):
        g = g.sort_values("rate")
        ax.plot(g["rate"], g["avg_ms"], marker="o", linewidth=2, markersize=7,
                label="%d replica%s" % (rep, "" if rep == 1 else "s"))
        for _, r in g.iterrows():
            ax.annotate("%.0f" % r["avg_ms"], (r["rate"], r["avg_ms"]), textcoords="offset points",
                        xytext=(0, 7), ha="center", fontsize=7)
            if r["errors"] > 0:
                ax.annotate("(%d err)" % r["errors"], (r["rate"], r["avg_ms"]), textcoords="offset points",
                            xytext=(0, -13), ha="center", fontsize=7, color="red")
    have = set(zip(df["replicas"], df["rate"]))
    missing = [(r, x) for r in (1, 2, 3) for x in RATES if (r, x) not in have]
    if missing:
        print("  WARNING graph1: missing runs (replicas, rate):", missing)
    ax.set_xticks(RATES)
    ax.set_xlabel("Request rate (req/s)")
    ax.set_ylabel("Average response time (ms)")
    ax.set_title("Graph 1: Average response time vs request rate")
    ax.grid(alpha=.3)
    ax.legend()
    ax.set_ylim(bottom=0)
    fig.tight_layout()
    fig.savefig(os.path.join(R, "graph1_response_time.png"), dpi=150)


def graph2():
    path = os.path.join(R, "raw", "r3_rate100_pods.csv")
    df = pd.read_csv(path)
    df = df[df["pod"].str.startswith("emi-web")].copy()
    if df.empty:
        raise RuntimeError("no emi-web rows in %s (kubectl top returned nothing). Fix metrics-server, then redo: "
                           "python3 run_experiments.py --replicas 3 --rates 100" % path)
    df["t"] = df["timestamp"] - df["timestamp"].min()
    df["cpu_pct"] = df["cpu_millicores"] / CPU_REQUEST_M * 100
    fig, ax = plt.subplots(figsize=(8, 5))
    for pod, g in df.groupby("pod"):
        g = g.sort_values("t")
        ax.plot(g["t"], g["cpu_pct"], marker="o", linewidth=2, label=pod)
    ax.axhline(100, ls=":", color="gray", label="CPU request (100%)")
    ax.axhline(250, ls="--", color="red", alpha=.5, label="CPU limit (250%)")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("CPU utilisation (% of 100m request)")
    ax.set_title("Graph 2: Per-pod CPU, 100 req/s, 3 replicas")
    ax.set_ylim(bottom=0)
    ax.grid(alpha=.3)
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(R, "graph2_pod_cpu.png"), dpi=150)


def graph3():
    d = os.path.join(R, "autoscale")
    ph = pd.read_csv(os.path.join(d, "phases.csv"))
    hpa = pd.read_csv(os.path.join(d, "autoscale_hpa.csv"))
    pods = pd.read_csv(os.path.join(d, "autoscale_pods.csv"))
    pods = pods[pods["pod"].str.startswith("emi-web")]
    t0 = ph["start_ts"].min()
    t_end = ph["end_ts"].max() - t0
    hpa["t"] = hpa["timestamp"] - t0
    # clean HPA data: a blank/0 desired value means "not computed yet"
    hpa["desired_replicas"] = hpa["desired_replicas"].replace(0, float("nan"))
    hpa[["current_replicas", "desired_replicas"]] = hpa[["current_replicas", "desired_replicas"]].ffill()
    # per-timestamp numbers from kubectl top (fallback / cross-check)
    top = pods.groupby("timestamp").agg(n=("pod", "count"), cpu=("cpu_millicores", "mean")).reset_index()
    top["t"] = top["timestamp"] - t0
    top["util"] = top["cpu"] / CPU_REQUEST_M * 100

    fig, ax = plt.subplots(3, 1, sharex=True, figsize=(9, 8.5))
    xs, ys = [], []
    for _, r in ph.iterrows():                      # request rate = httperf rate of each phase
        xs += [r["start_ts"] - t0, r["end_ts"] - t0]
        ys += [r["rate_req_s"], r["rate_req_s"]]
    ax[0].plot(xs, ys, linewidth=2)
    ax[0].set_ylabel("Request rate (req/s)")
    ax[0].set_ylim(0, max(ys) * 1.2)

    if hpa["cpu_util_pct"].notna().any():
        ax[1].plot(hpa["t"], hpa["cpu_util_pct"], marker="o", linewidth=2, label="HPA average CPU utilisation")
    elif not top.empty:
        print("  NOTE graph3: HPA gave no CPU value, using kubectl top (mean of web pods / 100m request)")
        ax[1].plot(top["t"], top["util"], marker="o", linewidth=2, label="mean pod CPU (kubectl top)")
    else:
        raise RuntimeError("no CPU data at all in results/autoscale (metrics-server problem). Redo run_autoscale.py")
    ax[1].axhline(50, ls="--", color="gray", label="HPA target 50%")
    ax[1].set_ylabel("Avg CPU utilisation (%)")
    ax[1].set_ylim(bottom=0)
    ax[1].legend(fontsize=8)

    if hpa["current_replicas"].notna().any():
        ax[2].step(hpa["t"], hpa["current_replicas"], where="post", linewidth=2, label="current replicas")
        ax[2].step(hpa["t"], hpa["desired_replicas"], where="post", ls="--", label="desired replicas")
    elif not top.empty:
        ax[2].step(top["t"], top["n"], where="post", linewidth=2, label="web pods (kubectl top)")
    ax[2].set_ylabel("Web replicas")
    ax[2].set_xlabel("Time (s)")
    ax[2].set_ylim(0, 5.5)
    ax[2].set_yticks([0, 1, 2, 3, 4, 5])
    ax[2].legend(fontsize=8)
    for a in ax:
        a.grid(alpha=.3)
        a.set_xlim(0, t_end)
        for _, r in ph.iterrows():                   # shade the 100 req/s phase
            if r["rate_req_s"] == ph["rate_req_s"].max():
                a.axvspan(r["start_ts"] - t0, r["end_ts"] - t0, color="orange", alpha=.08)
    ax[0].set_title("Graph 3: Autoscaling test (10 -> 100 -> 10 req/s)")
    fig.tight_layout()
    fig.savefig(os.path.join(R, "graph3_autoscaling.png"), dpi=150)


if __name__ == "__main__":
    for fn in (graph1, graph2, graph3):
        try:
            fn()
            print("ok:", fn.__name__)
        except Exception as e:
            print("FAILED %s: %s" % (fn.__name__, e))
