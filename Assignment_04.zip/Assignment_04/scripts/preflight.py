#!/usr/bin/env python3
"""Checks everything BEFORE a 40-minute experiment so you do not waste time.
   python3 preflight.py
"""
import http.client, os, random, shutil, subprocess, sys, time

HOST = os.environ.get("EMI_HOST", "emi.local")
PORT = int(os.environ.get("EMI_PORT", "80"))


def sh(*args):
    try:
        r = subprocess.run(list(args), capture_output=True, text=True, timeout=30)
        return r.returncode, (r.stdout + r.stderr).strip()
    except Exception as e:
        return 1, str(e)


def check(verbose=True):
    ok = True

    def good(m): print("  [ OK ]", m)
    def warn(m): print("  [WARN]", m)

    def fail(m):
        nonlocal ok
        ok = False
        print("  [FAIL]", m)

    print("Preflight checks")
    # 1. tools
    good("httperf found") if shutil.which("httperf") else fail("httperf not installed: sudo apt install httperf")

    # 2. VM resources
    try:
        import psutil
        cpus, mem = psutil.cpu_count(), psutil.virtual_memory().total / 2**30
        msg = "VM has %d CPUs, %.1f GB RAM" % (cpus, mem)
        (good if cpus >= 4 and mem >= 6 else warn)(msg + ("" if cpus >= 4 and mem >= 6 else
                                                           " (4+ CPUs and 6+ GB recommended; fewer CPUs = very slow, noisy results)"))
    except ImportError:
        warn("psutil missing: pip3 install psutil --break-system-packages")

    # 3. web pods ready
    rc, out = sh("kubectl", "get", "deploy", "emi-web", "-n", "emi", "-o", "jsonpath={.status.readyReplicas}")
    if rc == 0 and out.isdigit() and int(out) > 0:
        good("emi-web has %s ready pod(s)" % out)
    else:
        fail("no ready emi-web pods (kubectl get pods -n emi). Output: %s" % out)

    # 4. metrics-server / kubectl top
    rc, out = sh("kubectl", "top", "pods", "-n", "emi", "--no-headers")
    rows = [l for l in out.splitlines() if l.startswith("emi-web")] if rc == 0 else []
    if rows:
        good("kubectl top works (%d emi-web pod rows)" % len(rows))
    else:
        fail("kubectl top returns no data -> graphs 2 and 3 would be EMPTY.\n"
             "         Fix: minikube addons enable metrics-server ; kubectl get pods -n kube-system | grep metrics-server\n"
             "         (must be Running, wait 1-2 min) ; test: kubectl top nodes ; kubectl top pods -n emi\n"
             "         Output was: " + out[:200])

    # 5. latency through ingress
    lat, errs = [], 0
    for _ in range(20):
        body = "P=%d&rate=%d&n=%d" % (random.randint(10000, 900000), random.randint(5, 25), random.randint(6, 60))
        t = time.perf_counter()
        try:
            c = http.client.HTTPConnection(HOST, PORT, timeout=10)
            c.request("POST", "/api/emi", body, {"Content-Type": "application/x-www-form-urlencoded", "Connection": "close"})
            r = c.getresponse(); r.read(); c.close()
            if r.status != 200:
                errs += 1
        except Exception:
            errs += 1
        lat.append((time.perf_counter() - t) * 1000)
    avg = sum(lat) / len(lat)
    if errs:
        fail("%d/20 requests to http://%s failed (hosts file / ingress / pods?)" % (errs, HOST))
    elif avg > 150:
        warn("avg latency of a single request is %.0f ms (should be < 100 ms). Machine is overloaded or too small;"
             " results will be inflated" % avg)
    else:
        good("20 sequential requests through the ingress: avg %.1f ms, 0 errors" % avg)
    print("Preflight:", "PASSED" if ok else "FAILED")
    return ok


if __name__ == "__main__":
    sys.exit(0 if check() else 1)
