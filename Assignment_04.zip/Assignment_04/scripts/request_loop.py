#!/usr/bin/env python3
"""Milestone 3: keep sending requests (default 10/s) and log every one; shows failures and version changes.
   python request_loop.py --duration 120 --log ../results/rolling_update_loop.csv
Stop with Ctrl+C. Exit code 1 if any request failed.
"""
import argparse, csv, http.client, json, random, sys, time
from urllib.parse import urlparse

ap = argparse.ArgumentParser()
ap.add_argument("--url", default="http://emi.local/api/emi")
ap.add_argument("--interval", type=float, default=0.1)
ap.add_argument("--duration", type=int, default=0, help="seconds, 0 = until Ctrl+C")
ap.add_argument("--log", default="request_loop.csv")
a = ap.parse_args()
u = urlparse(a.url)
total = failed = 0
last_ver = None
end = time.time() + a.duration if a.duration else None
with open(a.log, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["time", "status", "servedBy", "version", "ms"])
    try:
        while end is None or time.time() < end:
            t0 = time.perf_counter()
            status, pod, ver = 0, "", ""
            try:
                body = json.dumps({"P": random.randint(10000, 900000), "rate": random.randint(5, 25), "n": random.randint(6, 60)})
                c = http.client.HTTPConnection(u.hostname, u.port or 80, timeout=10)
                c.request("POST", u.path or "/", body, {"Content-Type": "application/json", "Connection": "close"})
                r = c.getresponse()
                raw = r.read()
                c.close()
                status = r.status
                if status == 200:
                    d = json.loads(raw)
                    pod, ver = d.get("servedBy", ""), d.get("version", "")
            except Exception as e:
                status = 0
            ms = (time.perf_counter() - t0) * 1000
            total += 1
            stamp = time.strftime("%H:%M:%S")
            if status != 200:
                failed += 1
                print("%s FAILED status=%s" % (stamp, status), flush=True)
            elif ver != last_ver:
                print("%s now serving version %s (pod %s)" % (stamp, ver, pod), flush=True)
                last_ver = ver
            w.writerow([stamp, status, pod, ver, round(ms, 1)])
            f.flush()
            time.sleep(max(0, a.interval - (time.perf_counter() - t0)))
    except KeyboardInterrupt:
        pass
print("TOTAL=%d FAILED=%d" % (total, failed))
sys.exit(1 if failed else 0)
