#!/bin/bash

RATE=$1
DUR=$2
TAG=$3

N=$((RATE*DUR))
SESS=/tmp/sess_$TAG.txt
OUT=results/${TAG}_httperf.txt

python3 scripts/gen_sessions.py $N $SESS

GOT=$(grep -c "^/api/emi" $SESS)

if [ "$GOT" -ne "$N" ]; then
    echo "ERROR: Expected $N sessions, generated $GOT"
    exit 1
fi

httperf --server emi.local --port 80 \
--wsesslog=$N,0,$SESS \
--rate=$RATE --timeout=10 \
--add-header='Content-Type: application/json\n' \
> $OUT 2>&1

echo "$TAG completed. Expected sessions: $N"
