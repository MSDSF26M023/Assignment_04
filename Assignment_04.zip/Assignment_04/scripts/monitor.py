#!/usr/bin/env python3
"""Profiling: host CPU every 1 s, `kubectl top pods` every 15 s (and HPA every 15 s with --hpa).
Writes <prefix>_host_cpu.csv, <prefix>_pods.csv, [<prefix>_hpa.csv, <prefix>_hpa_raw.txt]
All CSVs have a timestamp column (epoch seconds).   Needs:  pip install psutil
Standalone:  python monitor.py --out ../results/raw/test --duration 60 [--hpa]
"""
import argparse, csv, json, os, subprocess, sys, threading, time
try:
    import psutil
except ImportError:
    psutil = None

NS = "emi"


def _kubectl(*args):
    try:
        r = subprocess.run(["kubectl", *args], capture_output=True, text=True, timeout=30)
        return r.stdout if r.returncode == 0 else ""
    except Exception:
        return ""


def _cpu_m(s):
    if s.endswith("n"):
        return float(s[:-1]) / 1e6
    if s.endswith("u"):
        return float(s[:-1]) / 1e3
    if s.endswith("m"):
        return float(s[:-1])
    return float(s) * 1000


def _mem_mib(s):
    for suf, k in (("Ki", 1 / 1024), ("Mi", 1), ("Gi", 1024)):
        if s.endswith(suf):
            return float(s[:-2]) * k
    return float(s) / (1024 * 1024)


class Monitor:
    def __init__(self, prefix, hpa=False, interval=15):
        self.prefix, self.hpa, self.interval = prefix, hpa, interval
        self._stop = threading.Event()
        self._threads = []
        self.top_rows = 0
        self._warned = False

    def start(self):
        if psutil is None:
            sys.exit("psutil missing: pip install psutil")
        os.makedirs(os.path.dirname(os.path.abspath(self.prefix)), exist_ok=True)
        self._stop.clear()
        self._threads = [threading.Thread(target=self._host, daemon=True),
                         threading.Thread(target=self._k8s, daemon=True)]
        for t in self._threads:
            t.start()

    def stop(self):
        self._stop.set()
        for t in self._threads:
            t.join(timeout=60)

    def _host(self):
        with open(self.prefix + "_host_cpu.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["timestamp", "cpu_percent"])
            psutil.cpu_percent(None)
            while not self._stop.is_set():
                pct = psutil.cpu_percent(interval=1)      # blocks 1 s
                w.writerow([round(time.time(), 2), pct])
                f.flush()

    def _k8s(self):
        pf = open(self.prefix + "_pods.csv", "w", newline="")
        pw = csv.writer(pf)
        pw.writerow(["timestamp", "pod", "cpu_millicores", "mem_mib"])
        hf = hw = raw = None
        if self.hpa:
            hf = open(self.prefix + "_hpa.csv", "w", newline="")
            hw = csv.writer(hf)
            hw.writerow(["timestamp", "current_replicas", "desired_replicas", "cpu_util_pct"])
            raw = open(self.prefix + "_hpa_raw.txt", "w")
        try:
            while not self._stop.is_set():
                t0 = time.time()
                ts = round(t0, 2)
                out = _kubectl("top", "pods", "-n", NS, "--no-headers")
                got = 0
                for line in out.splitlines():
                    p = line.split()
                    if len(p) >= 3:
                        pw.writerow([ts, p[0], round(_cpu_m(p[1]), 1), round(_mem_mib(p[2]), 1)])
                        got += 1
                self.top_rows += got
                if got == 0 and not self._warned:
                    print("  WARNING: kubectl top returned no data (metrics-server not ready?)", flush=True)
                    self._warned = True
                pf.flush()
                if self.hpa:
                    raw.write("# %s (epoch %s)\n%s\n" % (time.strftime("%H:%M:%S"), ts,
                              _kubectl("get", "hpa", "emi-web", "-n", NS)))
                    raw.flush()
                    cur = des = util = ""
                    try:
                        st = json.loads(_kubectl("get", "hpa", "emi-web", "-n", NS, "-o", "json")).get("status", {})
                        cur, des = st.get("currentReplicas", ""), st.get("desiredReplicas", "")
                        for m in st.get("currentMetrics") or []:
                            if m.get("type") == "Resource" and m["resource"]["name"] == "cpu":
                                util = m["resource"]["current"].get("averageUtilization", "")
                    except Exception:
                        pass
                    hw.writerow([ts, cur, des, util])
                    hf.flush()
                self._stop.wait(max(0.0, self.interval - (time.time() - t0)))
        finally:
            for fh in (pf, hf, raw):
                if fh:
                    fh.close()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--duration", type=int, default=0, help="seconds (0 = until Ctrl+C)")
    ap.add_argument("--hpa", action="store_true")
    a = ap.parse_args()
    m = Monitor(a.out, hpa=a.hpa)
    m.start()
    try:
        time.sleep(a.duration) if a.duration else threading.Event().wait()
    except KeyboardInterrupt:
        pass
    m.stop()
